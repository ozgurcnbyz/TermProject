/** Automatically generated file. DO NOT MODIFY */
package edu.sabanciuniv.it592;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}